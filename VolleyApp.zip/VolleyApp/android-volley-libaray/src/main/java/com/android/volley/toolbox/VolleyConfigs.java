package com.android.volley.toolbox;

public class VolleyConfigs {
	public static final int SOCKET_TIMEOUT = 3000;
}
