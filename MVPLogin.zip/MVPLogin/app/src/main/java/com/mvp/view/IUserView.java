package com.mvp.view;

public interface IUserView {
	int getID();

	String getFristName();

	String getLastName();

	void setFirstName(String firstName);

	void setLastName(String lastName);

}
