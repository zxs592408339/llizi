package com.ittx.android1601.fragment.parameter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.ittx.android1601.R;

/**
 * Fragment -> Activity
 * Activity->Fragment
 * FragmentA <- Activity ->FragmentB
 */
public class ArgumentActivity extends AppCompatActivity implements ArgumentListFragment.OnArguementItemLisenter{
    private TextView mContentTxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_argument_layout);
        mContentTxt = (TextView) findViewById(R.id.argument_txt);

        ArgumentListFragment argumentListFragment = new ArgumentListFragment();

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.argument_framelayout,argumentListFragment)
                .commit();
    }

    @Override
    public void onItemClick(String message) {
        mContentTxt.setText(message);
    }
}
