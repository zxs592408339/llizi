package com.ittx.android1601.fragment.parameter;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ittx.android1601.R;

public class ArgumentContentFragment extends Fragment {
    private static final String MESSAGE = "MESSAGE";
    private TextView mContentTxt;
    private String message;

    /**
     * 实例化Fragment并传递参数
     *
     * @param msg
     * @return
     */
    public static Fragment newInstance(String msg) {
        ArgumentContentFragment argumentContentFragment = new ArgumentContentFragment();
        Bundle bundle = new Bundle();
        bundle.putString(MESSAGE, msg);
        argumentContentFragment.setArguments(bundle);
        return argumentContentFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            message = bundle.getString(MESSAGE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_news_content_layout, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mContentTxt = (TextView) getView().findViewById(R.id.arguemtn_content_txt);
        mContentTxt.setText(message);
    }
}
