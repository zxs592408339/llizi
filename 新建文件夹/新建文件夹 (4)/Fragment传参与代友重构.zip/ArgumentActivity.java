package com.ittx.android1601.fragment.parameter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ittx.android1601.R;

/**
 * Fragment -> Activity
 * Activity->Fragment
 * FragmentA <- Activity ->FragmentB
 */
public class ArgumentActivity extends AppCompatActivity implements ArgumentListFragment.OnArguementItemLisenter{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_argument_layout);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.argument_framelayout,ArgumentListFragment.newInstance())
                .commit();
    }

    @Override
    public void onItemClick(String message) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.argument_content_layout,ArgumentContentFragment.newInstance(message))
                .commit();
    }
}
