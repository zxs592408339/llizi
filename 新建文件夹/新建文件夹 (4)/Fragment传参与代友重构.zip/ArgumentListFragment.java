package com.ittx.android1601.fragment.parameter;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ittx.android1601.R;

public class ArgumentListFragment extends Fragment implements AdapterView.OnItemClickListener{
    private ListView mListView;
    private String[] arrays = new String[]{"新闻1","新闻2","新闻3","新闻4"};
    private OnArguementItemLisenter mOnArguementItemLisenter;

    interface OnArguementItemLisenter{
        void onItemClick(String message);
    }

    public static Fragment newInstance(){
        ArgumentListFragment argumentListFragment = new ArgumentListFragment();
        return argumentListFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof OnArguementItemLisenter ){
            this.mOnArguementItemLisenter = (OnArguementItemLisenter) context;
        }else{
            throw new RuntimeException(context.toString()
                    + " must implement OnArguementItemLisenter");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_news_list_layout, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mListView = (ListView) getView().findViewById(R.id.news_listView);
        ArrayAdapter adapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1,arrays);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ArrayAdapter adapter = (ArrayAdapter) parent.getAdapter();
        String item = (String) adapter.getItem(position);
        if(mOnArguementItemLisenter != null) {
            mOnArguementItemLisenter.onItemClick(item);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mOnArguementItemLisenter = null;
    }
}
