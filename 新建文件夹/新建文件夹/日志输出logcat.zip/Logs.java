package com.ittx.android1601;

import android.util.Log;

public class Logs {
    private static final String tag = "android1601";
    private static final boolean isDebug = true; //控制程序日志输出状态

    public static void v(String msg) {
        if (isDebug)
            Log.v(tag, msg);
    }

    public static void d(String msg) {
        if (isDebug)
            Log.d(tag, msg);
    }

    public static void i(String msg) {
        if (isDebug)
            Log.i(tag, msg);
    }

    public static void w(String msg) {
        if (isDebug)
            Log.w(tag, msg);
    }

    public static void e(String msg) {
        if (isDebug)
            Log.e(tag, msg);
    }
}
