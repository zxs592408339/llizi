package com.ittx.android1601;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class LogcatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logcat_layout);

        Logs.v("用来记录详细信息的Log.v()");
        Logs.d("用来记录调试信息的Log.d()");
        Logs.i("用来记录通告信息的Log.i()");
        Logs.w("用来记录警告信息的Log.w()");
        Logs.e("用来记录详细信息的Log.v()");

        String str = "你好";
        Logs.v("str >>>>>>>  :"+str);

        str.toString();
    }
}
