package com.ittx.android1601.ui;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.ittx.android1601.R;

public class GridViewActivity extends AppCompatActivity {
    private GridView mGridView;
    private int[] imageResIds = {R.drawable.list1, R.drawable.list2, R.drawable.list3,
            R.drawable.list4, R.drawable.list1, R.drawable.list2,
            R.drawable.list3, R.drawable.list1, R.drawable.list2};
    private MyImageGridViewAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view_layout);
        mGridView = (GridView) findViewById(R.id.widget_gridview);

        mAdapter = new MyImageGridViewAdapter(this);
        mAdapter.setImageResIds(imageResIds);

        mGridView.setAdapter(mAdapter);

    }

    public class MyImageGridViewAdapter extends BaseAdapter {
        private int[] imageResIds = new int[]{}; //数据源
        private LayoutInflater layoutInflater;  //解析xml布局为View对象

        public MyImageGridViewAdapter(Context context) {
            layoutInflater = LayoutInflater.from(context);
        }

        /**
         * 设置数据源
         * @param resIds
         */
        public void setImageResIds(int[] resIds) {
            this.imageResIds = resIds;
        }

        @Override
        public int getCount() {
            return imageResIds.length;
        }

        @Override
        public Object getItem(int position) {
            return imageResIds[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null){
                convertView = layoutInflater.inflate(R.layout.item_grid_view_layout,null);
                ImageView imageView = (ImageView) convertView.findViewById(R.id.imageview);
                convertView.setTag(imageView);
            }
            ImageView imageView = (ImageView) convertView.getTag();
            imageView.setImageResource((Integer) getItem(position));

            return convertView;
        }
    }

}
