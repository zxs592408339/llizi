package com.ittx.android1601.adapter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.ittx.android1601.R;

import java.util.ArrayList;
import java.util.HashMap;

public class MySimpleAdapterActivity extends AppCompatActivity {
    public ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_simple_adapter_layout);
        mListView = (ListView) findViewById(R.id.adapter_simple_listview);

        ArrayList arrayList = getListData();

        String[] from = {"icon", "title", "content"};
        int[] to = {R.id.adapter_simple_imageview, R.id.adapter_simple_title_txt, R.id.adapter_simple_content_txt};
        SimpleAdapter adapter = new SimpleAdapter(this, arrayList, R.layout.item_adapter_simple_view, from, to);

        mListView.setAdapter(adapter);
    }

    public  ArrayList getListData() {
        ArrayList listData = new ArrayList();

        HashMap<String, Object> item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list1);
        item.put("title", "1【多店通用】乡村基");
        item.put("content", "20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list2);
        item.put("title", "2【多店通用】廖记棒棒鸡");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list3);
        item.put("title", "3【5店通用】九锅一堂");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list4);
        item.put("title", "4【幸福大道】囧囧串串");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);


        item.put("icon", R.drawable.list1);
        item.put("title", "5【多店通用】乡村基");
        item.put("content", "20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list2);
        item.put("title", "6【多店通用】廖记棒棒鸡");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list3);
        item.put("title", "7【5店通用】九锅一堂");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list4);
        item.put("title", "8【幸福大道】囧囧串串");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        return listData;
    }
}
