package com.ittx.android1601.ui.menu;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ittx.android1601.R;

public class ContextMenuActivity extends AppCompatActivity {
    private ListView mListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_context_menu_layout);
        mListView = (ListView) findViewById(R.id.menu_context_listview);
        String[] arrays = new String[]{"选项菜单","上下文菜单","弹出菜单"};
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrays);
        mListView.setAdapter(adapter);

        registerForContextMenu(mListView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.my_option_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
}
