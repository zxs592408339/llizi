package com.ittx.android1601.ui.tab;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TabHost;

import com.ittx.android1601.R;
import com.ittx.android1601.ui.GridViewActivity;
import com.ittx.android1601.ui.ProgressBarActivity;
import com.ittx.android1601.ui.adapter.MySimpleAdapterActivity;

public class TabMainActivity extends TabActivity {
    private TabHost mTabHost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_main_layout);
        mTabHost = getTabHost();


        LayoutInflater inflater = LayoutInflater.from(this);
        View tabview1 = inflater.inflate(R.layout.tab_item_layout,null);

        TabHost.TabSpec tabSpec1 = mTabHost.newTabSpec("tab1");
        tabSpec1.setIndicator(tabview1);
        tabSpec1.setContent(new Intent(this, MySimpleAdapterActivity.class));

        TabHost.TabSpec tabSpec2 = mTabHost.newTabSpec("tab2");
        tabSpec2.setIndicator("页卡2");
        tabSpec2.setContent(new Intent(this, GridViewActivity.class));

        TabHost.TabSpec tabSpec3 = mTabHost.newTabSpec("tab3");
        tabSpec3.setIndicator("页卡3");
        tabSpec3.setContent(new Intent(this, ProgressBarActivity.class));

        mTabHost.addTab(tabSpec1);
        mTabHost.addTab(tabSpec2);
        mTabHost.addTab(tabSpec3);


    }
}
