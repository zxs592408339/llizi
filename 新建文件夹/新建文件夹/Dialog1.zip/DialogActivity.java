package com.ittx.android1601.ui.dialog;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ittx.android1601.R;

public class DialogActivity extends AppCompatActivity implements View.OnClickListener{
    private Button mProgressBtn,mDialogConfirmBtn,mDialogSelectBtn,mLoginBtn,mToastBtn;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_layout);
        mProgressBtn = (Button) findViewById(R.id.dialog_progress_btn);
        mDialogConfirmBtn = (Button) findViewById(R.id.dialog_alert_confirg_btn);
        mDialogSelectBtn = (Button) findViewById(R.id.dialog_alert_select_btn);
        mLoginBtn = (Button) findViewById(R.id.dialog_alert_login_btn);
        mToastBtn = (Button) findViewById(R.id.dialog_alert_toast_btn);
        mProgressBtn.setOnClickListener(this);
        mDialogConfirmBtn.setOnClickListener(this);
        mDialogSelectBtn.setOnClickListener(this);
        mLoginBtn.setOnClickListener(this);
        mToastBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.dialog_progress_btn:
                progressDialog = new ProgressDialog(this);
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.setMessage("文件正在下载中...");
                progressDialog.show(); //显示
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        for(int i = 1; i <= 100; i++){
                            progressDialog.setProgress(i);
                            SystemClock.sleep(50);
                        }
                        progressDialog.dismiss();//取消
                    }
                }).start();
                break;
            case R.id.dialog_alert_confirg_btn:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("操作提示");
                builder.setMessage("是否退出程序!");
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"取消成功!",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNeutralButton("继续", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"继续成功!",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"操作成功!",Toast.LENGTH_SHORT).show();
                    }
                });


                AlertDialog dialog = builder.create();
                dialog.show();
                break;
            case R.id.dialog_alert_select_btn:
                builder = new AlertDialog.Builder(this);
                builder.setTitle("兴趣爱好");
                String[] singleChoices = new String[]{"读书","写字","运动","画画"};
                builder.setSingleChoiceItems(singleChoices, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"你选择是 "+which,Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"操作成功!",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(DialogActivity.this,"取消成功!",Toast.LENGTH_SHORT).show();
                    }
                });
                AlertDialog dialog1 = builder.create();
                dialog1.show();

                break;
            case R.id.dialog_alert_login_btn:
                LoginAlertDialog loginAlertDialog = new LoginAlertDialog(this);
                loginAlertDialog.show();
                break;

            case R.id.dialog_alert_toast_btn:
                Toast toast = new Toast(this);

                LayoutInflater inflater = LayoutInflater.from(this);
                View view = inflater.inflate(R.layout.dialog_toast_layout,null);
                TextView text = (TextView) view.findViewById(R.id.toast_title_text);
                text.setText("自定义Toast学习!");

                toast.setView(view);
                toast.setGravity(Gravity.CENTER,0,0);
                toast.show();
                break;
        }
    }
}
