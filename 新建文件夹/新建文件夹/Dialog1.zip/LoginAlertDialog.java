package com.ittx.android1601.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ittx.android1601.R;

public class LoginAlertDialog extends AlertDialog{
    private Context context;
    private Button mLoginBtn;
    private EditText mUserNameEdit,mPasswordEdit;
    protected LoginAlertDialog(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_login_layout);
        mLoginBtn = (Button) findViewById(R.id.login_login_btn);
        mUserNameEdit = (EditText) findViewById(R.id.login_username_edit);
        mPasswordEdit = (EditText) findViewById(R.id.login_pasword_edit);
        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = mUserNameEdit.getText().toString();
                String password = mPasswordEdit.getText().toString();
                if(userName.equals("admin") && password.equals("123456")){
                    Toast.makeText(context,"登录成功!",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(context,"登录失败，用户名或密码错误！",Toast.LENGTH_SHORT).show();
                }
                dismiss();
            }
        });

    }
}
