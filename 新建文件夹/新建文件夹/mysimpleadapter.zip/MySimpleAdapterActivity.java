package com.ittx.android1601.adapter;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.ittx.android1601.R;
import com.ittx.android1601.TextViewActivity;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *  ListView 列表控件
 *  Adapter 适配器  数据源与ListView之间建立桥梁
 *
 *   适配器名称            数据源                             每一项目布局（ItemView）
 *   ArrayAdapter         数组或者List<String>                 只能是TextView
 *   SimpleAdapter        List<? extends Map<String,?>         任意布局
 *   自定义BaseAdapter
 */
public class MySimpleAdapterActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    public ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_simple_adapter_layout);
        mListView = (ListView) findViewById(R.id.adapter_simple_listview);

        ArrayList arrayList = getListData();

//        String[] from = {"icon", "title", "content"};
//        int[] to = {R.id.adapter_simple_imageview, R.id.adapter_simple_title_txt, R.id.adapter_simple_content_txt};
//        SimpleAdapter adapter = new SimpleAdapter(this, arrayList, R.layout.item_adapter_simple_view, from, to);

        MySimpleBaseAdapter adapter = new MySimpleBaseAdapter(this,arrayList);

        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(this); //注册listview项点击事件
    }

    public  ArrayList getListData() {
        ArrayList<HashMap<String, Object>> listData = new ArrayList();

        HashMap<String, Object> item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list1);
        item.put("title", "1自定义【多店通用】乡村基");
        item.put("content", "20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list2);
        item.put("title", "2自定义【多店通用】廖记棒棒鸡");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list3);
        item.put("title", "3【5店通用】九锅一堂");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list4);
        item.put("title", "4【幸福大道】囧囧串串");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);


        item.put("icon", R.drawable.list1);
        item.put("title", "5【多店通用】乡村基");
        item.put("content", "20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list2);
        item.put("title", "6【多店通用】廖记棒棒鸡");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list3);
        item.put("title", "7【5店通用】九锅一堂");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new HashMap<String, Object>();
        item.put("icon", R.drawable.list4);
        item.put("title", "8【幸福大道】囧囧串串");
        item.put("content", "32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        return listData;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(position == 1){
            startActivity(new Intent(this, TextViewActivity.class));
        }

        //onItemClick事件中获取每一个控件显示值
        MySimpleBaseAdapter adpater = (MySimpleBaseAdapter) parent.getAdapter();
        HashMap<String,Object> item = (HashMap<String, Object>) adpater.getItem(position);
        String title = (String) item.get("title");
        String content = (String) item.get("content");
        Snackbar.make(view,"title :"+title,Snackbar.LENGTH_SHORT).show();

    }


    public  ArrayList getListMessageData() {
        ArrayList<MessageBean> listData = new ArrayList();

        MessageBean item = new MessageBean();
        item.setIcon(R.drawable.list1);
        item.setTitle("1自定义【多店通用】乡村基");
        item.setContent("20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon(R.drawable.list2);
        item.setTitle("2自定义【多店通用】廖记棒棒鸡");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon( R.drawable.list3);
        item.setTitle("3【5店通用】九锅一堂");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon( R.drawable.list4);
        item.setTitle("4【幸福大道】囧囧串串");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);


        item.setIcon( R.drawable.list1);
        item.setTitle("5【多店通用】乡村基");
        item.setContent("20元代金券！全场通用，可叠加使用，提供免费WiFi！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon( R.drawable.list2);
        item.setTitle("6【多店通用】廖记棒棒鸡");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon( R.drawable.list3);
        item.setTitle("7【5店通用】九锅一堂");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        item = new MessageBean();
        item.setIcon( R.drawable.list4);
        item.setTitle("8【幸福大道】囧囧串串");
        item.setContent("32元代金券！全场通用，可叠加使用，节假日通用！");
        listData.add(item);

        return listData;
    }
}
