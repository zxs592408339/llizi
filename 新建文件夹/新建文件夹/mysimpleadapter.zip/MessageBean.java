package com.ittx.android1601.adapter;

/**
 * Created by Administrator on 2016/6/1.
 */
public class MessageBean {
    private int icon; //图标
    private String title; //标题
    private String content; //内容

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
