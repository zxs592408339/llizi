package com.ittx.android1601.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ittx.android1601.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MySimpleBaseAdapter extends BaseAdapter {
    private List<HashMap<String,Object>> list = new ArrayList<>();
    private LayoutInflater layoutInflater;
    public MySimpleBaseAdapter(Context context,List<HashMap<String,Object>> l){
        this.list = l;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     *  1.获取ListView每一项显示的ItemView
     * 2.将数据源相应值赋给ItemView中控件
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.item_adapter_simple_view,null);//将布局解析生成View对象
        //从View对象中获取控件实例
        ImageView iconImg = (ImageView) v.findViewById(R.id.adapter_simple_imageview);
        TextView titleTxt = (TextView) v.findViewById(R.id.adapter_simple_title_txt);
        TextView contentTxt = (TextView) v.findViewById(R.id.adapter_simple_content_txt);

        HashMap<String,Object> item = (HashMap<String, Object>) getItem(position);
        int icon = (int) item.get("icon");
        String title = (String) item.get("title");
        String content = (String) item.get("content");

//        iconImg.setBackgroundResource(icon);  // 通过代码设置ImageView背景  background
        iconImg.setImageResource(icon); //通过代码设置 ImageView控件内容  src
        titleTxt.setText(title);
        contentTxt.setText(content);

        return v;
    }
}
