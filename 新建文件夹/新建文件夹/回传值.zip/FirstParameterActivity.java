package com.ittx.android1601.parameter;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ittx.android1601.Logs;
import com.ittx.android1601.R;

public class FirstParameterActivity extends AppCompatActivity implements View.OnClickListener{
    public TextView mShowBackMessageTxt;
    public Button mToBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_parameter_layout);
        mShowBackMessageTxt = (TextView) findViewById(R.id.parameter_back_first_txt);
        mToBtn = (Button) findViewById(R.id.parameter_back_first_btn);

        mToBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.parameter_back_first_btn:
                Intent intent = new Intent(this,SecondBackParameterActivity.class);
//                startActivity(intent);
                //// TODO: 2016/5/31  回传值 第一步: 启动Activity使用： startActivityForResult
                int requestCode = 101;
                startActivityForResult(intent,requestCode);
                break;
        }
    }

    //// TODO: 2016/5/31 回传值 第二步:重写 onActivityResult 用于接收回传值
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Logs.e("requestCode :"+requestCode + " resultCode :"+resultCode);
        String msg = data.getStringExtra("MESSAGE");
        Logs.e("返回值是 :"+msg);

        mShowBackMessageTxt.setText("requestCode :"+requestCode + " resultCode :"+resultCode);
        mShowBackMessageTxt.append("返回值是 :"+msg);
    }
}
