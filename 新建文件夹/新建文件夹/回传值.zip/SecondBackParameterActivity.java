package com.ittx.android1601.parameter;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.ittx.android1601.R;

public class SecondBackParameterActivity extends AppCompatActivity implements View.OnClickListener{
    public EditText mInputEdit;
    public Button mBackBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_back_parameter_layout);
        mInputEdit = (EditText) findViewById(R.id.parameter_second_edit);
        mBackBtn = (Button) findViewById(R.id.parameter_second_btn);
        mBackBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.parameter_second_btn:
                int resultCode = 201;
                String backMsg = mInputEdit.getText().toString();

                //// TODO: 2016/5/31 回传值 第三步:  
                Intent data = getIntent();
                data.putExtra("MESSAGE",backMsg);

                setResult(resultCode,data);

                finish();
                break;
        }
    }
}
