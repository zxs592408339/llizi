package com.ittx.android1601.adapter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ittx.android1601.R;

public class MyArrayAdpaterActivity extends AppCompatActivity {
    public ListView mListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_array_adpater_layout);
        // TODO: 2016/6/1 实例化控件ListView 
        mListView = (ListView) findViewById(R.id.adapter_array_listview);

        // TODO: 2016/6/1 构造数据源  arrays 
        String[] arrays = new String[]{"android","ios","java","j2ee","wphone","net","javascript","spring","structs","html","css","hibernate"};

        // TODO: 2016/6/1 实例适配器  adapter 
        ArrayAdapter adapter = new ArrayAdapter(this,R.layout.item_adapter_array_view,arrays);
//        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrays);
        // TODO: 2016/6/1 设置adapter
        mListView.setAdapter(adapter);

    }
}
