package com.ittx.android1601.ui.menu;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.ittx.android1601.R;

/**
 *
 */
public class ToolBarActivity extends AppCompatActivity {
    public Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tool_bar_layout);
        mToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        mToolbar.inflateMenu(R.menu.my_option_menu);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.my_option_add:
                        Toast.makeText(ToolBarActivity.this,"添加成功",Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.my_option_delete:
                        Toast.makeText(ToolBarActivity.this,"删除成功",Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });

        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ToolBarActivity.this,"返回",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

}
