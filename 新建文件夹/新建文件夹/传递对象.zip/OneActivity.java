package com.ittx.android1601.parameter;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.ittx.android1601.Logs;
import com.ittx.android1601.R;
import com.ittx.android1601.model.Student;
import com.ittx.android1601.model.Teacher;

public class OneActivity extends AppCompatActivity implements View.OnClickListener{
    public EditText mInputEdit;
    public Button mToBtn,mBundleBtn,mStudentBtn,mParcelableBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_layout);

        mInputEdit = (EditText) findViewById(R.id.parameter_message_edit);
        mToBtn = (Button) findViewById(R.id.parameter_to_btn);
        mBundleBtn = (Button) findViewById(R.id.parameter_to_bundle_btn);
        mStudentBtn = (Button) findViewById(R.id.parameter_to_student_btn);
        mParcelableBtn = (Button) findViewById(R.id.parameter_to_parcelable_btn);

        mToBtn.setOnClickListener(this);
        mBundleBtn.setOnClickListener(this);
        mStudentBtn.setOnClickListener(this);
        mParcelableBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String message = mInputEdit.getText().toString();
        switch(v.getId()){
            case R.id.parameter_to_btn:
                Intent intent = new Intent(this,TwoActivity.class);
                intent.putExtra("MESSAGE",message);
                intent.putExtra("SEX",true);
                Logs.v("message :"+message);
                startActivity(intent);
                break;
            case R.id.parameter_to_bundle_btn:
                Bundle bundle = new Bundle();
                bundle.putString("MESSAGE_BUNDEL",message);
                bundle.putBoolean("SEX",false);
                Intent intent1 = new Intent(this,TwoActivity.class);
                intent1.putExtra("BUNDEL",bundle);

                startActivity(intent1);
                break;
            case R.id.parameter_to_student_btn:
                Student student = new Student();
                student.setName(message);
                student.setAge(23);
                student.setSex(true);

                Intent it = new Intent(this,TwoActivity.class);
                it.putExtra("STUDENT",student);

                startActivity(it);
                break;
            case R.id.parameter_to_parcelable_btn:
                Teacher teacher = new Teacher(message,19,111);
                Intent i = new Intent(this,TwoActivity.class);
                i.putExtra("TEACHER",teacher);
                startActivity(i);
                break;
        }

    }
}
