package com.ittx.android1601.model;

import java.io.Serializable;

public class Student implements Serializable {
    private String name; //姓名
    private int age; //年龄
    private boolean sex; //true 男, false 女

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }


}
