package com.ittx.android1601.parameter;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.ittx.android1601.Logs;
import com.ittx.android1601.R;
import com.ittx.android1601.model.Student;
import com.ittx.android1601.model.Teacher;

public class TwoActivity extends AppCompatActivity {
    public TextView mShowMessageTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parameter_two_layout);
        mShowMessageTxt = (TextView) findViewById(R.id.parameter_show_message_txt);

        Intent intent = this.getIntent();  //获取Intent对象实例通过getIntent()

//        baseTypeParameter(intent);
//        bundelParameter(intent);
//        getStudentParameter(intent);
        getTeacherParcelable(intent);
    }

    public void getTeacherParcelable(Intent intent){
        Teacher teacher = intent.getParcelableExtra("TEACHER");
        mShowMessageTxt.setText("姓名:" + teacher.name + " 学号 :"
                + (teacher.number) + " 年龄 :" + teacher.age);
    }

    public void getStudentParameter(Intent intent) {
        Student student = (Student) intent.getSerializableExtra("STUDENT");
        mShowMessageTxt.setText("姓名:" + student.getName() + " 性别 :"
                + (student.isSex() ? "男" : "女") + " 年龄 :" + student.getAge());
    }

    public void bundelParameter(Intent intent) {
        Bundle bundle = intent.getBundleExtra("BUNDEL");
        String messge = bundle.getString("MESSAGE_BUNDEL");
        boolean sex = bundle.getBoolean("SEX");
        mShowMessageTxt.setText("接收到的信息是 :" + messge + " 性别 :" + (sex == true ? "男" : "女"));
    }

    public void baseTypeParameter(Intent intent) {
        String message = intent.getStringExtra("MESSAGE");
        Logs.v("twoActivity message :" + message);
        boolean sex = intent.getBooleanExtra("SEX", false);
        mShowMessageTxt.setText("信息 :" + message + ", 性别 :" + sex);
    }
}
